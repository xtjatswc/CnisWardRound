/** Automatically generated file. DO NOT MODIFY */
package com.bgxt.datatimepickerdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}