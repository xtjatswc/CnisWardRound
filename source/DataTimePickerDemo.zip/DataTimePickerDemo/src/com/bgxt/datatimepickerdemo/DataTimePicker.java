package com.bgxt.datatimepickerdemo;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import android.app.Activity;
import android.os.Bundle;
import android.widget.DatePicker;
import android.widget.DatePicker.OnDateChangedListener;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

public class DataTimePicker extends Activity {
	private DatePicker datePicker;
	private TimePicker timePicker;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_datatimepicker);

		datePicker = (DatePicker) findViewById(R.id.dpPicker);
		timePicker = (TimePicker) findViewById(R.id.tpPicker);

		datePicker.init(2013, 8, 20, new OnDateChangedListener() {

			@Override
			public void onDateChanged(DatePicker view, int year,
					int monthOfYear, int dayOfMonth) {
				// ��ȡһ���������󣬲���ʼ��Ϊ��ǰѡ�е�ʱ��
				Calendar calendar = Calendar.getInstance();
				calendar.set(year, monthOfYear, dayOfMonth);
				SimpleDateFormat format = new SimpleDateFormat(
						"yyyy��MM��dd��  HH:mm");
				Toast.makeText(DataTimePicker.this,
						format.format(calendar.getTime()), Toast.LENGTH_SHORT)
						.show();
			}
		});

		timePicker.setIs24HourView(true);
		timePicker
				.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
					@Override
					public void onTimeChanged(TimePicker view, int hourOfDay,
							int minute) {
						Toast.makeText(DataTimePicker.this,
								hourOfDay + "Сʱ" + minute + "����",
								Toast.LENGTH_SHORT).show();
					}
				});

	}
}
